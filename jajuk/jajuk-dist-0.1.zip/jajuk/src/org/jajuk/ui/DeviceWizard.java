/*
 *  Jajuk
 *  Copyright (C) 2003 bflorat
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *  $Revision: 1.12 $
 */

package org.jajuk.ui;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import layout.TableLayout;

import org.jajuk.base.Device;
import org.jajuk.base.DeviceManager;
import org.jajuk.base.ITechnicalStrings;
import org.jajuk.i18n.Messages;
import org.jajuk.ui.views.DeviceView;
import org.jajuk.util.Util;
import org.jajuk.util.log.Log;

/**
 * Device creation wizzard
 * 
 * @author bflorat @created 9 nov. 2003
 */
public class DeviceWizard extends JFrame implements ActionListener,ITechnicalStrings {
	JPanel jpMain;
	JPanel jp1;
	JLabel jlType;
	JComboBox jcbType;
	JLabel jlName;
	JTextField jtfName;
	JLabel jlUrl;
	JTextField jtfUrl;
	JButton jbUrl;
	JLabel jlMountPoint;
	JTextField jtfMountPoint;
	JCheckBox jcbRefresh;
	JCheckBox jcbAutoMount;
	JCheckBox jcbAutoRefresh;
	JCheckBox jcboxSynchronized;
	JComboBox jcbSynchronized;
	JPanel jp2;
	ButtonGroup bgSynchro;
	JRadioButton jrbFullSynchro;
	JRadioButton jrbPartialSynchro;
	JCheckBox jcb1;
	JCheckBox jcb2;
	JCheckBox jcb3;
	JPanel jpButtons;
	JButton jbOk;
	JButton jbCancel;
	
	/**New device flag*/
	private boolean bNew = true;
	
	/**Current device*/
	Device device;
	
	
	public DeviceWizard() {
		super("Device wizard");
		setSize(800, 600);
		setLocation(org.jajuk.Main.jframe.getX()+100,org.jajuk.Main.jframe.getY()+100);
		jpMain = new JPanel();
		jpMain.setLayout(new BoxLayout(jpMain,BoxLayout.Y_AXIS));
		jp1 = new JPanel();
		jp1.setBorder(BorderFactory.createEmptyBorder(25, 15, 0, 15));
		double size1[][] = { { 0.5, 0.45,0.05 }, {
				20, 20, 20, 20, 20,20,20, 20, 20, 20, 20,20,20 }
		};
		jp1.setLayout(new TableLayout(size1));
		jlType = new JLabel("Device Type : ");
		jcbType = new JComboBox();
		for (int i = 0; i < Device.sDeviceTypes.length; i++) {
			jcbType.addItem(Device.sDeviceTypes[i]);
		}
		jlName = new JLabel("Device name : ");
		jtfName = new JTextField();
		jlUrl = new JLabel("Device url : ");
		jtfUrl = new JTextField();
		jbUrl = new JButton(Util.getIcon(ICON_OPEN_FILE));
		jbUrl.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
		jbUrl.addActionListener(this);
		jlMountPoint = new JLabel("Unix mount Point : ");
		jtfMountPoint = new JTextField();
		String sOS = (String)System.getProperties().get("os.name");
		if (sOS.trim().toLowerCase().lastIndexOf("windows")!=-1){
			jlMountPoint.setEnabled(false);
			jtfMountPoint.setEnabled(false);
		}
		jcbRefresh = new JCheckBox("Perform an instant refresh");
		jcbRefresh.addActionListener(this);
		jcbAutoMount = new JCheckBox("Auto mount at startup");
		jcbAutoMount.addActionListener(this);
		jcbAutoRefresh = new JCheckBox("Auto refresh at startup");
		jcboxSynchronized = new JCheckBox("Synchronized with : ");
		jcboxSynchronized.addActionListener(this);
		jcbSynchronized = new JComboBox();
		jcbSynchronized.setEnabled(false);
		ArrayList alDevices = DeviceManager.getDevices();
		Iterator it = alDevices.iterator();
		while (it.hasNext()) {
			Device device = (Device) it.next();
			jcbSynchronized.addItem(device.getName());
		}
		//Default automount behavior
		jcbType.addActionListener(this);
		bgSynchro = new ButtonGroup();
		jrbFullSynchro = new JRadioButton("Full synchronization");
		jrbFullSynchro.setBorder(BorderFactory.createEmptyBorder(0, 25, 0, 0));
		jrbFullSynchro.addActionListener(this);
		jrbPartialSynchro = new JRadioButton("Partial synchronization");
		jrbPartialSynchro.setBorder(BorderFactory.createEmptyBorder(0, 25, 0, 0));
		jrbPartialSynchro.setEnabled(false);
		jrbPartialSynchro.addActionListener(this);
		bgSynchro.add(jrbFullSynchro);
		bgSynchro.add(jrbPartialSynchro);
		jcb1 = new JCheckBox("If a track is deleted from this device, delete it from source device");
		jcb1.setBorder(BorderFactory.createEmptyBorder(0, 50, 0, 0));
		jcb1.setEnabled(false);
		jcb2 = new JCheckBox("If a track is deleted from source device, delete it from this device");
		jcb2.setBorder(BorderFactory.createEmptyBorder(0, 50, 0, 0));
		jcb2.setEnabled(false);
		jcb3 = new JCheckBox("If a track is desynchronized from source device, delete it from this device");
		jcb3.setBorder(BorderFactory.createEmptyBorder(0, 50, 0, 0));
		jcb3.setEnabled(false);
		jp1.add(jlType, "0,0");
		jp1.add(jcbType, "1,0");
		jp1.add(jlName, "0,2");
		jp1.add(jtfName, "1,2");
		jp1.add(jlUrl, "0,4");
		jp1.add(jtfUrl, "1,4");
		jp1.add(jbUrl, "2,4");
		jp1.add(jlMountPoint, "0,6");
		jp1.add(jtfMountPoint, "1,6");
		jp1.add(jcbRefresh, "0,8");
		jp1.add(jcbAutoMount, "0,10");
		jp1.add(jcbAutoRefresh, "1,10");
		jp1.add(jcboxSynchronized, "0,12");
		jp1.add(jcbSynchronized, "1,12");
		double size2[][] = { { 0.99 }, {
			20, 20, 20, 20, 20, 20, 20, 20, 20, 20 }
		};
		jp2 = new JPanel();
		jp2.setLayout(new TableLayout(size2));
		jp2.setBorder(BorderFactory.createEmptyBorder(0, 15, 25, 15));
		jp2.add(jrbFullSynchro, "0,1");
		jp2.add(jrbPartialSynchro, "0,3");
		jp2.add(jcb1, "0,5");
		jp2.add(jcb2, "0,7");
		jp2.add(jcb3, "0,9");
		if (jcbSynchronized.getItemCount()==0){
			jcboxSynchronized.setEnabled(false);
			jcbSynchronized.setEnabled(false);
			jrbFullSynchro.setEnabled(false);
		}
		
		//buttons
		jpButtons = new JPanel();
		jpButtons.setLayout(new FlowLayout(FlowLayout.CENTER));
		jbOk = new JButton("OK");
		jbOk.requestFocus();
		jbOk.addActionListener(this);
		jbCancel = new JButton("Cancel");
		jbCancel.addActionListener(this);
		jpButtons.add(jbOk);
		jpButtons.add(jbCancel);
		
		jpMain.add(jp1);
		jpMain.add(jp2);
		jpMain.add(Box.createVerticalGlue());
		jpMain.add(jpButtons);
		setContentPane(jpMain);
		show();
	}
	
	/**
	 * Update widgets for default state
	 */
	public void updateWidgetsDefault(){
		jcbRefresh.setSelected(true);
		jcbAutoRefresh.setEnabled(false);
		jcbAutoMount.setSelected(true);
		jrbFullSynchro.setSelected(true);//default synchro mode
		jrbFullSynchro.setEnabled(false);
	}
	
	/**
	 * Update widgets for device property state 
	 */
	public void updateWidgets(Device device){
		bNew = false;
		this.device = device;
		updateWidgetsDefault();
		jcbType.setSelectedItem(device.getDeviceTypeS());
		jtfName.setText(device.getName());
		jtfUrl.setText(device.getUrl());
		jtfMountPoint.setText(device.getMountPoint());
		jcbRefresh.setEnabled(false); //no instant refresh for updates
		jcbRefresh.setSelected(false);
		if (TRUE.equals(device.getProperty(DEVICE_OPTION_AUTO_MOUNT))){
			jcbAutoMount.setSelected(true);
			jcbAutoRefresh.setEnabled(true);
		}
		if (TRUE.equals(device.getProperty(DEVICE_OPTION_AUTO_REFRESH))){
			jcbAutoRefresh.setEnabled(true);
			jcbAutoRefresh.setSelected(true);
		}
		jcbSynchronized.removeItemAt(DeviceManager.getDevices().indexOf(device));//do not propose to synchronize a device with itself
		if (jcbSynchronized.getItemCount()==0){
			jcboxSynchronized.setEnabled(false);
			jcbSynchronized.setEnabled(false);
			jrbFullSynchro.setEnabled(false);
		}
		String sSynchroSource = device.getProperty(DEVICE_OPTION_SYNCHRO_SOURCE); 
		if ( sSynchroSource != null){
			jrbFullSynchro.setEnabled(true);
			jrbPartialSynchro.setEnabled(true);
			jcboxSynchronized.setSelected(true);
			jcboxSynchronized.setEnabled(true);
			jcbSynchronized.setEnabled(true);
			jcbSynchronized.setSelectedIndex(DeviceManager.getDevices().indexOf(DeviceManager.getDevice(sSynchroSource)));
			if (DEVICE_OPTION_SYNCHRO_MODE_FULL.equals(device.getProperty(DEVICE_OPTION_SYNCHRO_MODE))){
				jrbFullSynchro.setSelected(true);
			}
			else{
				jrbPartialSynchro.setSelected(true);
				if (TRUE.equals(device.getProperty(DEVICE_OPTION_SYNCHRO_OPT1))){
					jcb1.setSelected(true);
					jcb1.setEnabled(true);
				}
				if (TRUE.equals(device.getProperty(DEVICE_OPTION_SYNCHRO_OPT2))){
					jcb2.setSelected(true);
					jcb2.setEnabled(true);
				}	
				if (TRUE.equals(device.getProperty(DEVICE_OPTION_SYNCHRO_OPT3))){
					jcb3.setSelected(true);
					jcb3.setEnabled(true);
				}	
			}
		}
	}
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == jcbAutoMount) {
			if (jcbAutoMount.isSelected()) {
				jcbAutoRefresh.setEnabled(true);
			} else {
				jcbAutoRefresh.setSelected(false);
				jcbAutoRefresh.setEnabled(false);
			}
		} else if (e.getSource() == jcboxSynchronized) {
			if (jcboxSynchronized.isSelected()) {
				jcbSynchronized.setEnabled(true);
				jrbFullSynchro.setEnabled(true);
				jrbPartialSynchro.setEnabled(true);
			} else {
				jcbSynchronized.setEnabled(false);
				jrbFullSynchro.setEnabled(false);
				jrbFullSynchro.setSelected(true);
				jrbPartialSynchro.setEnabled(false);
				jrbFullSynchro.setSelected(false);
				jcb1.setEnabled(false);
				jcb1.setSelected(false);
				jcb2.setEnabled(false);
				jcb2.setSelected(false);
				jcb3.setEnabled(false);
				jcb3.setSelected(false);
			}
		} else if (e.getSource() == jrbFullSynchro) {
			if (jrbFullSynchro.isSelected()) {
				jcb1.setEnabled(false);
				jcb1.setSelected(false);
				jcb2.setEnabled(false);
				jcb2.setSelected(false);
				jcb3.setEnabled(false);
				jcb3.setSelected(false);
			}
		}
		else if (e.getSource() == jrbPartialSynchro) {
			if (jrbPartialSynchro.isSelected()) {
				jcb1.setEnabled(true);
				jcb2.setEnabled(true);
				jcb3.setEnabled(true);
			} else {
				jcb1.setEnabled(false);
				jcb1.setSelected(false);
				jcb2.setEnabled(false);
				jcb2.setSelected(false);
				jcb3.setEnabled(false);
				jcb3.setSelected(false);
			}
		}
		else if (e.getSource() == jbOk){
			if (bNew){
				device = DeviceManager.registerDevice(jtfName.getText(),jcbType.getSelectedIndex(),jtfUrl.getText(),jtfMountPoint.getText());
			}
			else{
				device.setDeviceType(jcbType.getSelectedIndex());
				device.setName(jtfName.getText());
				device.setUrl(jtfUrl.getText());
				device.setMountPoint(jtfMountPoint.getText());
			}
			
			device.setProperty(DEVICE_OPTION_AUTO_MOUNT,Boolean.toString(jcbAutoMount.isSelected()));
			device.setProperty(DEVICE_OPTION_AUTO_REFRESH,Boolean.toString(jcbAutoRefresh.isSelected()));
			if (jcbSynchronized.isEnabled() && jcbSynchronized.getSelectedItem() != null){
				device.setProperty(DEVICE_OPTION_SYNCHRO_SOURCE,((Device)DeviceManager.getDevices().get(jcbSynchronized.getSelectedIndex())).getId());
				if (jrbFullSynchro.isSelected()){
					device.setProperty(DEVICE_OPTION_SYNCHRO_MODE,DEVICE_OPTION_SYNCHRO_MODE_FULL);
				}
				else{
					device.setProperty(DEVICE_OPTION_SYNCHRO_MODE,DEVICE_OPTION_SYNCHRO_MODE_PARTIAL);
					if (jcb1.isSelected()){
						device.setProperty(DEVICE_OPTION_SYNCHRO_OPT1,TRUE);
					}
					else{
						device.setProperty(DEVICE_OPTION_SYNCHRO_OPT1,FALSE);
					}
					if (jcb2.isSelected()){
						device.setProperty(DEVICE_OPTION_SYNCHRO_OPT2,TRUE);
					}
					else{
						device.setProperty(DEVICE_OPTION_SYNCHRO_OPT2,FALSE);
					}
					if (jcb3.isSelected()){
						device.setProperty(DEVICE_OPTION_SYNCHRO_OPT3,TRUE);
					}
					else{
						device.setProperty(DEVICE_OPTION_SYNCHRO_OPT3,FALSE);
					}
				}
			}
			else{  //no synchro
				device.removeProperty(DEVICE_OPTION_SYNCHRO_MODE);
				device.removeProperty(DEVICE_OPTION_SYNCHRO_OPT1);
				device.removeProperty(DEVICE_OPTION_SYNCHRO_OPT2);
				device.removeProperty(DEVICE_OPTION_SYNCHRO_OPT3);
				device.removeProperty(DEVICE_OPTION_SYNCHRO_SOURCE);
			}
			if (jcbRefresh.isSelected()){
				try{
					device.mount();
					device.refresh();
				}
				catch(Exception e2){
					Log.error("112",device.getName(),e2);
					Messages.showErrorMessage("112",device.getName());
				}
				
			}
			ViewManager.notify(EVENT_VIEW_REFRESH_REQUEST,DeviceView.getInstance());
			dispose();
			if (bNew){
				Messages.showInfoMessage("Device_created");//$NON-NLS-1$
			}
		}
		else if (e.getSource() == jbCancel){
			dispose();  //close window
		}
		else if (e.getSource() == jbUrl){
			JFileChooser jfc = new JFileChooser("Please choose a directory");
			jfc.setMultiSelectionEnabled(false);
			jfc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			int returnVal = jfc.showOpenDialog(this);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				java.io.File file = jfc.getSelectedFile();
				jtfUrl.setText(file.getAbsolutePath());	
			}
		}
		else if(e.getSource() == jcbType){
			switch(jcbType.getSelectedIndex()){
					case 0: //directory
						jcbAutoMount.setSelected(true);
						break;
					case 1: //file cd
						jcbAutoMount.setSelected(false);
						break;
					case 2: //remote
						jcbAutoMount.setSelected(false);
						break;
					case 3: //ext dd
						jcbAutoMount.setSelected(false);
						break;
					case 4: //player
						jcbAutoMount.setSelected(false);
						break;
				}
		}
	}
}
