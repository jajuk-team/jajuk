/*
 *  Jajuk
 *  Copyright (C) 2003 bflorat
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *  $Revision: 1.15 $
 */
package org.jajuk.base;

import org.jajuk.i18n.Messages;
import org.jajuk.ui.InformationJPanel;
import org.jajuk.util.log.Log;

/**
 *  abstract class for music player, independent from real implementation
 *
 * @author     bflorat
 * @created    12 oct. 2003
 */
public class Player {

	private static File fCurrent;
	private static IPlayerImpl pCurrentPlayerImpl;
	/** Lock to ensure 2 players can be lauched*/
	private static final byte[] bLock = new byte[0];
	
	/**
	 * Asynchronous play for specified file with specified time interval
	 * @param file to play
	 * @param position in % of the file length ex:10
	 * @param length in ms 
	 */
	public static synchronized void play(File file,final float fPosition,final long length) {
		fCurrent = file;
		pCurrentPlayerImpl = file.getTrack().getType().getPlayerImpl();
		Thread thread = new Thread() {
			public void run() {
				try {
					synchronized(bLock){  //ultimate concurrency protection
						pCurrentPlayerImpl.play(fCurrent,fPosition,length);
					}
				} catch (Exception e) {
					Log.error("007",fCurrent.getAbsolutePath(), e); //$NON-NLS-1$
					InformationJPanel.getInstance().setMessage(Messages.getString("Error.007")+" : "+fCurrent.getAbsolutePath(),InformationJPanel.ERROR);//$NON-NLS-1$
					Player.stop();
					FIFO.getInstance().finished();
				}			
			}
		};
		thread.setPriority(Thread.MAX_PRIORITY);
		thread.start();
	}
	
	/**
	 * Stop the played track
	 * @param type
	 */
	public static synchronized void stop() {
		try {
			if (fCurrent!=null){
				fCurrent.getTrack().getType().getPlayerImpl().stop();
			}
		} catch (Exception e) {
			Log.error("008",fCurrent.getName(),e); //$NON-NLS-1$
		}
	}

}
